const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const alunosRoutes = require('./routes/alunos');
const professoresRoutes = require('./routes/professores');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/alunos', alunosRoutes);
app.use('/api/professores', professoresRoutes);

app.listen(3000, () => {
    console.log('🚀 Backend rodando em http://localhost:3000');
});
