const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/alunos', require('./routes/alunos'));
app.use('/api/professores', require('./routes/professores'));

app.listen(3000, () => {
    console.log('🚀 Backend rodando em http://localhost:3000');
});
