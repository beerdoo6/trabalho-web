const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');

const router = express.Router();

/* ===== CADASTRO ===== */
router.post('/register', async (req, res) => {
    const { email, senha, tipo } = req.body;

    if (!email || !senha || !tipo) {
        return res.status(400).json({ error: 'Dados incompletos' });
    }

    try {
        const hash = await bcrypt.hash(senha, 10);

        db.query(
            'INSERT INTO usuarios (email, senha, tipo) VALUES (?,?,?)',
            [email, hash, tipo],
            err => {
                if (err) {
                    console.error(err);

                    if (err.code === 'ER_DUP_ENTRY') {
                        return res.status(409).json({
                            error: 'Email já cadastrado'
                        });
                    }

                    return res.status(500).json({
                        error: 'Erro ao cadastrar'
                    });
                }

                res.status(201).json({ success: true });
            }
        );
    } catch (e) {
        res.status(500).json({ error: 'Erro interno' });
    }
});

/* ===== LOGIN ===== */
router.post('/login', (req, res) => {
    const { email, senha } = req.body;

    db.query(
        'SELECT * FROM usuarios WHERE email = ?',
        [email],
        async (err, r) => {
            if (err) {
                return res.status(500).json({ error: 'Erro no servidor' });
            }

            if (r.length === 0) {
                return res.status(401).json({ error: 'Usuário não encontrado' });
            }

            const valido = await bcrypt.compare(senha, r[0].senha);
            if (!valido) {
                return res.status(401).json({ error: 'Senha incorreta' });
            }

            const token = jwt.sign(
                { id: r[0].id, tipo: r[0].tipo },
                'segredo',
                { expiresIn: '1d' }
            );

            res.json({
                token,
                tipo: r[0].tipo
            });
        }
    );
});

module.exports = router;
