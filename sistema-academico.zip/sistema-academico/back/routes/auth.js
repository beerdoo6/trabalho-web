const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');
const router = express.Router();

router.post('/register', async (req, res) => {
    const { email, senha, tipo } = req.body;
    const hash = await bcrypt.hash(senha, 10);

    db.query(
        'INSERT INTO usuarios (email, senha, tipo) VALUES (?,?,?)',
        [email, hash, tipo],
        err => {
            if (err) return res.json({ error: 'Erro ao cadastrar' });
            res.json({ success: true });
        }
    );
});

router.post('/login', (req, res) => {
    const { email, senha } = req.body;

    db.query('SELECT * FROM usuarios WHERE email=?', [email], async (err, r) => {
        if (r.length === 0) return res.json({ error: 'Usuário não encontrado' });

        const valido = await bcrypt.compare(senha, r[0].senha);
        if (!valido) return res.json({ error: 'Senha incorreta' });

        const token = jwt.sign({ id: r[0].id }, 'segredo');
        res.json({ token, tipo: r[0].tipo });
    });
});

module.exports = router;
