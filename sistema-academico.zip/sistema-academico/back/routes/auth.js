const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');

const router = express.Router();

router.post('/login', (req, res) => {
    const { email, senha } = req.body;

    db.query(
        'SELECT * FROM usuarios WHERE email = ?',
        [email],
        async (err, results) => {
            if (err) return res.status(500).json(err);
            if (results.length === 0)
                return res.status(401).json({ error: 'Usuário não encontrado' });

            const usuario = results[0];
            const valido = await bcrypt.compare(senha, usuario.senha_hash);

            if (!valido)
                return res.status(401).json({ error: 'Senha inválida' });

            const token = jwt.sign(
                { id: usuario.id, tipo: usuario.tipo },
                'segredo_jwt',
                { expiresIn: '1h' }
            );

            res.json({ token, tipo: usuario.tipo });
        }
    );
});

module.exports = router;
