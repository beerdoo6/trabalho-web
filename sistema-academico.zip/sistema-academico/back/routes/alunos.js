const router = require('express').Router();
const db = require('../db');

router.get('/', (_, res) => {
    db.query('SELECT * FROM alunos', (_, r) => res.json(r));
});

router.post('/', (req, res) => {
    db.query(
        'INSERT INTO alunos (nome,email) VALUES (?,?)',
        [req.body.nome, req.body.email],
        () => res.json({ success: true })
    );
});

router.delete('/:id', (req, res) => {
    db.query('DELETE FROM alunos WHERE id=?', [req.params.id], () => {
        res.json({ success: true });
    });
});

module.exports = router;
