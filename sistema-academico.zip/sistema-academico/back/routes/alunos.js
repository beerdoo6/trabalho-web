const express = require('express');
const db = require('../db');
const auth = require('../middleware/auth');

const router = express.Router();

router.post('/', auth, (req, res) => {
    const { nome, email, curso } = req.body;

    db.query(
        'INSERT INTO alunos (nome, email, curso) VALUES (?, ?, ?)',
        [nome, email, curso],
        err => {
            if (err) return res.status(500).json(err);
            res.json({ message: 'Aluno cadastrado com sucesso' });
        }
    );
});

module.exports = router;
