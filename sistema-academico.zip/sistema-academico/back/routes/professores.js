const express = require('express');
const db = require('../db');
const auth = require('../middleware/auth');

const router = express.Router();

router.post('/', auth, (req, res) => {
    const { nome, email, disciplina } = req.body;

    db.query(
        'INSERT INTO professores (nome, email, disciplina) VALUES (?, ?, ?)',
        [nome, email, disciplina],
        err => {
            if (err) return res.status(500).json(err);
            res.json({ message: 'Professor cadastrado com sucesso' });
        }
    );
});

module.exports = router;
