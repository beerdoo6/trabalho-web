const router = require('express').Router();
const db = require('../db');

router.get('/', (_, res) => {
    db.query('SELECT * FROM professores', (_, r) => res.json(r));
});

router.post('/atribuir', (req, res) => {
    const { professor_id, turma_id, disciplina_id } = req.body;
    db.query(
        'INSERT INTO professor_turma VALUES (NULL,?,?,?)',
        [professor_id, turma_id, disciplina_id],
        () => res.json({ success: true })
    );
});

module.exports = router;
