const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');

// 🔐 Middleware: só admin
function onlyAdmin(req, res, next) {
    if (req.user.tipo !== 'admin') {
        return res.status(403).json({ error: 'Acesso negado' });
    }
    next();
}

/* ================== LISTAR ALUNOS ================== */
router.get('/alunos', auth, onlyAdmin, (req, res) => {
    db.query(
        "SELECT id, email FROM usuarios WHERE tipo='aluno'",
        (err, result) => {
            if (err) return res.json({ error: 'Erro no banco' });
            res.json(result);
        }
    );
});

/* ================== LISTAR PROFESSORES ================== */
router.get('/professores', auth, onlyAdmin, (req, res) => {
    db.query(
        "SELECT id, email FROM usuarios WHERE tipo='professor'",
        (err, result) => {
            if (err) return res.json({ error: 'Erro no banco' });
            res.json(result);
        }
    );
});

/* ================== EXCLUIR USUÁRIO ================== */
router.delete('/usuario/:id', auth, onlyAdmin, (req, res) => {
    db.query(
        'DELETE FROM usuarios WHERE id=? AND tipo!="admin"',
        [req.params.id],
        err => {
            if (err) return res.json({ error: 'Erro ao excluir' });
            res.json({ success: true });
        }
    );
});

module.exports = router;
