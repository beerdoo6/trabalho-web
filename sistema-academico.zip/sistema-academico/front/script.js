// Configurações
const API_URL = 'http://localhost:3000';
let isBackendOnline = false;

// Elementos do DOM
const loginForm = document.getElementById('loginForm');
const emailInput = document.getElementById('email');
const senhaInput = document.getElementById('senha');
const togglePassword = document.getElementById('togglePassword');
const loginBtn = document.getElementById('loginBtn');
const loginText = document.getElementById('loginText');
const loginLoading = document.getElementById('loginLoading');
const errorMessage = document.getElementById('errorMessage');
const successMessage = document.getElementById('successMessage');
const backendStatus = document.getElementById('backendStatus');
const dbStatus = document.getElementById('dbStatus');

// Verificar status do sistema ao carregar
document.addEventListener('DOMContentLoaded', checkSystemStatus);

// Mostrar/ocultar senha
togglePassword.addEventListener('click', function() {
    const type = senhaInput.getAttribute('type') === 'password' ? 'text' : 'password';
    senhaInput.setAttribute('type', type);
    this.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash"></i>';
});

// Função para verificar status do sistema
async function checkSystemStatus() {
    try {
        // Verificar backend
        const response = await fetch(`${API_URL}/api/test`, { 
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        
        if (response.ok) {
            backendStatus.textContent = 'Online ✓';
            backendStatus.style.color = '#27ae60';
            isBackendOnline = true;
            
            // Verificar banco de dados
            const data = await response.json();
            dbStatus.textContent = 'Conectado ✓';
            dbStatus.style.color = '#27ae60';
        } else {
            backendStatus.textContent = 'Offline ✗';
            backendStatus.style.color = '#e74c3c';
            dbStatus.textContent = 'Desconectado ✗';
            dbStatus.style.color = '#e74c3c';
        }
    } catch (error) {
        backendStatus.textContent = 'Offline ✗';
        backendStatus.style.color = '#e74c3c';
        dbStatus.textContent = 'Desconectado ✗';
        dbStatus.style.color = '#e74c3c';
        showError('Backend offline. Inicie o servidor primeiro.');
    }
}

// Função para fazer login
async function fazerLogin(event) {
    if (event) event.preventDefault();
    
    const email = emailInput.value.trim();
    const senha = senhaInput.value.trim();
    
    // Validação básica
    if (!email || !senha) {
        showError('Por favor, preencha todos os campos.');
        return;
    }
    
    // Validação de email
    if (!isValidEmail(email)) {
        showError('Por favor, insira um e-mail válido.');
        return;
    }
    
    // Mostrar estado de loading
    setLoadingState(true);
    
    try {
        const response = await fetch(`${API_URL}/api/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, senha })
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            showSuccess('Login realizado com sucesso!');
            
            // Salvar token e dados do usuário
            localStorage.setItem('token', data.token);
            localStorage.setItem('usuario', JSON.stringify(data.usuario));
            
            // Redirecionar após 2 segundos
            setTimeout(() => {
                redirectToDashboard(data.usuario.tipo);
            }, 2000);
        } else {
            showError(data.error || 'Erro no login. Verifique suas credenciais.');
            setLoadingState(false);
        }
    } catch (error) {
        console.error('Erro:', error);
        showError('Não foi possível conectar ao servidor. Verifique se o backend está rodando.');
        setLoadingState(false);
    }
}

// Redirecionar para dashboard específico
function redirectToDashboard(tipo) {
    const dashboards = {
        'admin': 'admin-dashboard.html',
        'aluno': 'aluno-dashboard.html',
        'professor': 'professor-dashboard.html'
    };
    
    window.location.href = dashboards[tipo] || 'dashboard.html';
}

// Funções auxiliares
function showError(mensagem) {
    const errorText = document.getElementById('errorText');
    if (errorText) errorText.textContent = mensagem;
    errorMessage.style.display = 'flex';
    successMessage.style.display = 'none';
    
    setTimeout(() => {
        errorMessage.style.display = 'none';
    }, 5000);
}

function showSuccess(mensagem) {
    const successText = document.getElementById('successText');
    if (successText) successText.textContent = mensagem;
    successMessage.style.display = 'flex';
    errorMessage.style.display = 'none';
}

function setLoadingState(carregando) {
    if (carregando) {
        loginText.style.display = 'none';
        loginLoading.style.display = 'flex';
        loginBtn.disabled = true;
    } else {
        loginText.style.display = 'flex';
        loginLoading.style.display = 'none';
        loginBtn.disabled = false;
    }
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Adicionar evento de submit ao formulário
loginForm.addEventListener('submit', fazerLogin);

// Preencher credenciais de teste ao clicar nos cards
document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  const emailInput = document.getElementById('email');
  const senhaInput = document.getElementById('senha');

  loginForm.addEventListener('submit', fazerLogin);
});